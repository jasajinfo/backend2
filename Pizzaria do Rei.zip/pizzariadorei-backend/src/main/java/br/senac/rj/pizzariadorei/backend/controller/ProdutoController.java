package br.senac.rj.pizzariadorei.backend.controller;

import br.senac.rj.pizzariadorei.backend.entity.Produto;
import br.senac.rj.pizzariadorei.backend.service.ProdutoService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/produto")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ProdutoController {

    private final ProdutoService service = new ProdutoService();

    @POST
    @Path("/salvar")
    public Response salvar(Produto produto) {
        return service.salvar(produto);
    }

    @GET
    @Path("/{id}")
    public Response buscar(@PathParam("id") Long id) {
        return service.buscar(id);
    }

    @GET
    @Path("/listar")
    public Response listar() {
        return service.listar();
    }
}
