package br.senac.rj.pizzariadorei.backend.dao;

import br.senac.rj.pizzariadorei.backend.entity.Endereco;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class EnderecoDao {

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("backendPU");

    public Endereco salvar(Endereco endereco) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Endereco salvo = em.merge(endereco);
            em.getTransaction().commit();
            return salvo;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }

    public Endereco buscarPorId(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Endereco.class, id);
        } finally {
            em.close();
        }
    }
}
