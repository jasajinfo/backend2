package br.senac.rj.pizzariadorei.backend.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "PAGAMENTO")
@Data
public class Pagamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pagamento")
    private Long idPagamento;

    @Column(name = "forma_pagamento", nullable = false, length = 50)
    private String formaPagamento;

    @Column(name = "detalhe_pagamento", length = 50)
    private String detalhePagamento;
}
