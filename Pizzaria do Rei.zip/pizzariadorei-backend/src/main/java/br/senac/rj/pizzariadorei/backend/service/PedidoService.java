package br.senac.rj.pizzariadorei.backend.service;

import br.senac.rj.pizzariadorei.backend.dao.PedidoDao;
import br.senac.rj.pizzariadorei.backend.entity.Pedido;
import jakarta.ws.rs.core.Response;

public class PedidoService {

    private final PedidoDao dao = new PedidoDao();

    public Response salvar(Pedido pedido) {
        Pedido salvo = dao.salvar(pedido);
        if (salvo == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"erro\":\"Não foi possível salvar o pedido.\"}")
                    .build();
        }
        return Response.ok(salvo).build();
    }

    public Response buscar(Long id) {
        Pedido pedido = dao.buscarPorId(id);
        if (pedido == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("{\"erro\":\"Pedido não encontrado.\"}")
                    .build();
        }
        return Response.ok(pedido).build();
    }
}
