package br.senac.rj.pizzariadorei.backend.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "PRODUTO")
@Data
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_produto")
    private Long idProduto;

    @Column(nullable = false, length = 100)
    private String nome;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private TipoProduto tipo;
}
