package br.senac.rj.pizzariadorei.backend.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Entity
@Table(name = "TAMANHO_PRECO",
       uniqueConstraints = @UniqueConstraint(columnNames = {"fk_id_produto", "tamanho"}))
@Data
public class TamanhoPreco {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tamanho_preco")
    private Long idTamanhoPreco;

    @ManyToOne
    @JoinColumn(name = "fk_id_produto", nullable = false)
    private Produto produto;

    @Column(nullable = false, length = 20)
    private String tamanho;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal preco;
}
