package br.senac.rj.pizzariadorei.backend.controller;

import br.senac.rj.pizzariadorei.backend.entity.Pedido;
import br.senac.rj.pizzariadorei.backend.service.PedidoService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/pedido")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PedidoController {

    private final PedidoService service = new PedidoService();

    @POST
    @Path("/salvar")
    public Response salvar(Pedido pedido) {
        return service.salvar(pedido);
    }

    @GET
    @Path("/{id}")
    public Response buscar(@PathParam("id") Long id) {
        return service.buscar(id);
    }
}
