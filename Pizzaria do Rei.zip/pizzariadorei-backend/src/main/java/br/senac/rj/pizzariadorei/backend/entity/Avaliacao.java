package br.senac.rj.pizzariadorei.backend.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "AVALIACAO")
@Data
public class Avaliacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_avaliacao")
    private Long idAvaliacao;

    @OneToOne
    @JoinColumn(name = "fk_id_pedido", unique = true, nullable = false)
    private Pedido pedido;

    @Column(nullable = false, length = 20)
    private String experiencia;

    @Column(columnDefinition = "TEXT")
    private String comentarios;

    @Column(name = "nota_eficiencia")
    private Integer notaEficiencia;

    @Column(name = "nota_solucao")
    private Integer notaSolucao;
}
