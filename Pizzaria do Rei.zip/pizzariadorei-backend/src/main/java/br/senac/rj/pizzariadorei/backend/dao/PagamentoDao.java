package br.senac.rj.pizzariadorei.backend.dao;

import br.senac.rj.pizzariadorei.backend.entity.Pagamento;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class PagamentoDao {

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("backendPU");

    public Pagamento salvar(Pagamento pagamento) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Pagamento salvo = em.merge(pagamento);
            em.getTransaction().commit();
            return salvo;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }

    public Pagamento buscarPorId(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Pagamento.class, id);
        } finally {
            em.close();
        }
    }
}
