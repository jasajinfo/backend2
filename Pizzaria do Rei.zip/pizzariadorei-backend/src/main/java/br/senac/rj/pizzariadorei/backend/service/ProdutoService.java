package br.senac.rj.pizzariadorei.backend.service;

import br.senac.rj.pizzariadorei.backend.dao.ProdutoDao;
import br.senac.rj.pizzariadorei.backend.entity.Produto;
import jakarta.ws.rs.core.Response;

public class ProdutoService {

    private final ProdutoDao dao = new ProdutoDao();

    public Response salvar(Produto produto) {
        Produto salvo = dao.salvar(produto);
        if (salvo == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"erro\":\"Não foi possível salvar o produto.\"}")
                    .build();
        }
        return Response.ok(salvo).build();
    }

    public Response buscar(Long id) {
        Produto produto = dao.buscarPorId(id);
        if (produto == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("{\"erro\":\"Produto não encontrado.\"}")
                    .build();
        }
        return Response.ok(produto).build();
    }

    public Response listar() {
        return Response.ok(dao.listarTodos()).build();
    }
}
