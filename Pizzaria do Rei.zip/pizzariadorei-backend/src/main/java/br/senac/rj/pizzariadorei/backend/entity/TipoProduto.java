package br.senac.rj.pizzariadorei.backend.entity;

public enum TipoProduto {
    Pizza,
    Bebida
}
