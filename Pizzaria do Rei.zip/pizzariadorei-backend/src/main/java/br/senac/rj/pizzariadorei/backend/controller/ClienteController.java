package br.senac.rj.pizzariadorei.backend.controller;

import br.senac.rj.pizzariadorei.backend.entity.Cliente;
import br.senac.rj.pizzariadorei.backend.service.ClienteService;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/cliente")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ClienteController {

    private final ClienteService service = new ClienteService();

    @POST
    @Path("/salvar")
    public Response salvar(Cliente cliente) {
        return service.salvar(cliente);
    }

    @GET
    @Path("/{id}")
    public Response buscar(@PathParam("id") Long id) {
        return service.buscar(id);
    }

    @POST
    @Path("/login")
    public Response login(Cliente cliente) {
        return service.login(cliente.getEmail(), cliente.getSenha());
    }
}
