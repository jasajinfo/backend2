package br.senac.rj.pizzariadorei.backend.service;

public class AuthService {

	public String gerarToken(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean validarToken(String token) {
		// TODO Auto-generated method stub
		return false;
	}

	public String getEmailDoToken(String token) {
		// TODO Auto-generated method stub
		return null;
	}

}
