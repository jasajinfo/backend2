package br.senac.rj.pizzariadorei.backend.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "ENDERECO")
@Data
public class Endereco {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_endereco")
    private Long idEndereco;

    @Column(nullable = false, length = 100)
    private String rua;

    @Column(nullable = false, length = 10)
    private String numero;

    @Column(length = 50)
    private String bairro;

    @Column(nullable = false, length = 50)
    private String cidade;

    @Column(length = 10)
    private String cep;

    @Column(name = "ponto_referencia", length = 100)
    private String pontoReferencia;
}
