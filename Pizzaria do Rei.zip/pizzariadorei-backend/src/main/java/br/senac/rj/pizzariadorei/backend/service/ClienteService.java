package br.senac.rj.pizzariadorei.backend.service;

import br.senac.rj.pizzariadorei.backend.dao.ClienteDao;
import br.senac.rj.pizzariadorei.backend.entity.Cliente;
import br.senac.rj.pizzariadorei.backend.util.PasswordUtil;
import jakarta.ws.rs.core.Response;

public class ClienteService {

    private final ClienteDao dao = new ClienteDao();
    private final AuthService authService = new AuthService();

    public Response salvar(Cliente cliente) {
        if (cliente.getSenha() != null) {
            cliente.setSenha(PasswordUtil.gerarHash(cliente.getSenha()));
        }

        Cliente salvo = dao.salvar(cliente);
        if (salvo == null) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"erro\":\"Não foi possível salvar o cliente.\"}")
                    .build();
        }
        return Response.ok(salvo).build();
    }

    public Response buscar(Long id) {
        Cliente cliente = dao.buscarPorId(id);
        if (cliente == null) {
            return Response.status(Response.Status.NOT_FOUND)
                    .entity("{\"erro\":\"Cliente não encontrado.\"}")
                    .build();
        }
        return Response.ok(cliente).build();
    }

    public Response login(String email, String senha) {
        Cliente cliente = dao.buscarPorEmail(email);
        if (cliente == null) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .entity("{\"erro\":\"Email ou senha inválidos.\"}")
                    .build();
        }

        boolean ok = PasswordUtil.verificarSenha(senha, cliente.getSenha());
        if (!ok) {
            return Response.status(Response.Status.UNAUTHORIZED)
                    .entity("{\"erro\":\"Email ou senha inválidos.\"}")
                    .build();
        }

        String token = authService.gerarToken(email);
        return Response.ok(token).build();
    }
}
