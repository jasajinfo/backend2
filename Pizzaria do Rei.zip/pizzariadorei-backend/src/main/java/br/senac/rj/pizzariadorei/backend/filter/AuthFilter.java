package br.senac.rj.pizzariadorei.backend.filter;

import br.senac.rj.pizzariadorei.backend.service.AuthService;
import jakarta.annotation.Priority;
import jakarta.ws.rs.Priorities;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;

import java.io.IOException;

@Provider
@Priority(Priorities.AUTHENTICATION)
public class AuthFilter implements ContainerRequestFilter {

    private final AuthService authService = new AuthService();

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        String path = requestContext.getUriInfo().getPath();

        if (path.equals("cliente/login") || path.equals("cliente/salvar")) {
            return;
        }

        String authHeader = requestContext.getHeaderString("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            abort(requestContext, "Token ausente ou formato inválido.");
            return;
        }

        String token = authHeader.substring("Bearer".length()).trim();

        if (!authService.validarToken(token)) {
            abort(requestContext, "Token inválido ou expirado.");
            return;
        }

        String email = authService.getEmailDoToken(token);
        requestContext.setProperty("clienteEmail", email);
    }

    private void abort(ContainerRequestContext ctx, String mensagem) {
        ctx.abortWith(
                Response.status(Response.Status.UNAUTHORIZED)
                        .entity("{\"erro\":\"" + mensagem + "\"}")
                        .build()
        );
    }
}
