package br.senac.rj.pizzariadorei.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

import java.io.Serializable;

@Embeddable
@Data
public class ItemPedidoId implements Serializable {

    @Column(name = "fk_id_pedido")
    private Long idPedido;

    @Column(name = "fk_id_produto")
    private Long idProduto;

    @Column(name = "tamanho_item", length = 20)
    private String tamanhoItem;
}
