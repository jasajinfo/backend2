package br.senac.rj.pizzariadorei.backend.config;

import java.util.HashSet;
import java.util.Set;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class JaxRsApplication extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<>();

        resources.add(br.senac.rj.pizzariadorei.backend.controller.ClienteController.class);
        resources.add(br.senac.rj.pizzariadorei.backend.controller.ProdutoController.class);
        resources.add(br.senac.rj.pizzariadorei.backend.controller.PedidoController.class);

        resources.add(br.senac.rj.pizzariadorei.backend.filter.AuthFilter.class);

        return resources;
    }
}
