package br.senac.rj.pizzariadorei.backend.dao;

import br.senac.rj.pizzariadorei.backend.entity.Pedido;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class PedidoDao {

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("backendPU");

    public Pedido salvar(Pedido pedido) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Pedido salvo = em.merge(pedido);
            em.getTransaction().commit();
            return salvo;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            e.printStackTrace();
            return null;
        } finally {
            em.close();
        }
    }

    public Pedido buscarPorId(Long id) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Pedido.class, id);
        } finally {
            em.close();
        }
    }
}

